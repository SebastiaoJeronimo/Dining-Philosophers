Precisa de dois includes que estão no ficheiro intro.tgz
que se pode descarregar do site do livro "OSTEP":
common.h
common_threads.h

Paulo Afonso Lopes
